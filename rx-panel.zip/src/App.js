import React from "react";
import { FabricLayout } from "@bit/mazyar.m1-rx.core";
import { Router } from "@reach/router";

function App() {
  return <FabricLayout>TEST</FabricLayout>;
}

export default App;
